package com.example.csti.data

data class usuario(
    val contacto: String = "",
    val contrasena: String = "",
    val correo: String = "",
    val estatus: String = "",
    val id_usuario: String = "",
    val nombre: String = "",
    val nombre_usuario: String = "",
    val rol: String = ""
)

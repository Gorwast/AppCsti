package com.example.csti.data

data class profesor(
    val id_profesor: Int = 0,
    val nombre_profesor: String = ""
)
